document.addEventListener('copy', function(e) {
  // Check if we're on the x.com website
  if (window.location.hostname.includes('x.com')) {
    // Get the selected text
    const selectedText = window.getSelection().toString();
    
    // Look for x.com links
    if (selectedText.includes('x.com')) {
      // Prevent the default copy behavior
      e.preventDefault();
      
      // Modify the text directly in the content script for better clipboard handling
      const modifiedText = selectedText.replace(/https?:\/\/(www\.)?x\.com/g, "https://vxtwitter.com");
      
      // Set the modified text to the clipboard
      e.clipboardData.setData('text/plain', modifiedText);
      console.log("Modified link copied to clipboard:", modifiedText);
    }
  }
});

// Add a listener for context menu clicks on links
document.addEventListener('mousedown', function(e) {
  // Check if right-clicking a link
  if (e.button === 2 && e.target.tagName === 'A') {
    // Store the link in a variable that can be accessed when copy is triggered
    window.lastRightClickedLink = e.target.href;
  }
});

// Special handling for copying links from the context menu
document.addEventListener('copy', function(e) {
  if (window.lastRightClickedLink && window.lastRightClickedLink.includes('x.com')) {
    e.preventDefault();
    const modifiedText = window.lastRightClickedLink.replace(/https?:\/\/(www\.)?x\.com/g, "https://vxtwitter.com");
    e.clipboardData.setData('text/plain', modifiedText);
    console.log("Modified context menu link copied:", modifiedText);
    window.lastRightClickedLink = null;
  }
});